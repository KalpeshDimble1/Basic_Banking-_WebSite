# Banking-System
This project is a task of The Sparks Foundation under GRIP Internship Program.
I have created a Online Banking System in which there are operations performed like 
transfer of money and the history of transaction.
